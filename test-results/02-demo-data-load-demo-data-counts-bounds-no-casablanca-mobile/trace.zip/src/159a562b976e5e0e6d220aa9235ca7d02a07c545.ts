import { expect, test } from '@playwright/test'
import { attachConsoleCollectors, assertNoHorizontalScroll, screenshot } from './helpers'

test('load demo data: counts, bounds, no casablanca', async ({ page }) => {
  const { consoleErrors, pageErrors, failedRequests } = attachConsoleCollectors(page)
  await page.goto('/')
  const more = page.getByText('More').first()
  if (await more.isVisible()) await more.click()
  await page.getByText('Load demo data').first().click()
  // confirm if dialog
  const confirm = page.getByRole('button', { name: /load|confirm|yes/i })
  if (await confirm.count()) await confirm.first().click()
  await page.waitForTimeout(500)
  await screenshot(page, 'demo-loaded')
  // basic count checks via DOM not exact; check orders count in localStorage
  const orders = await page.evaluate(() => JSON.parse(localStorage.getItem('nexatrack:v4:orders') || '[]'))
  expect(orders.length).toBe(20)
  for (const o of orders) {
    expect(o.lat).toBeGreaterThan(27.1)
    expect(o.lat).toBeLessThan(27.21)
    expect(o.lng).toBeGreaterThan(-13.27)
    expect(o.lng).toBeLessThan(-13.12)
    expect(JSON.stringify(o).toLowerCase()).not.toContain('casablanca')
  }
  await assertNoHorizontalScroll(page)
  expect(consoleErrors).toEqual([])
  expect(pageErrors).toEqual([])
  expect(failedRequests).toEqual([])
})
